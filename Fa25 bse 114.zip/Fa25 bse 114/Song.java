public class Song extends Media {
    private String genre;

    public Song(String title, double duration, int year, Artist artist, String genre) {
        super(title, duration, year, artist);
        this.genre = genre;
    }

    public String getGenre() {
        return genre;
    }

    @Override
    public void play() {
        System.out.println("Playing song \"" + getTitle() + "\" by "
                + getArtist().getName() + " [" + genre + "]");
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Song) {
            Song other = (Song) obj;

            return this.getTitle().equalsIgnoreCase(other.getTitle()) &&
                   this.getDurationSeconds() == other.getDurationSeconds() &&
                   this.getReleaseYear() == other.getReleaseYear() &&
                   this.getArtist().equals(other.getArtist()) &&
                   this.genre.equalsIgnoreCase(other.genre);
        }
        return false;
    }  }