import java.util.*;

public class TestDriver {
    public static void main(String[] args) {

        // Artists
        Artist a1 = new Artist("Atif Aslam", "Pakistan", 1000);
        Artist a2 = new Artist("Ali Zafar", "Pakistan", 2000);

        // Songs
        Song s1 = new Song("Dil", 200, 2020, a1, "Pop");
        Song s2 = new Song("RockStar", 180, 2019, a2, "Rock");
        Song s3 = new Song("Dil", 200, 2020, a1, "Pop"); // equal test

        // Podcasts
        PodcastEpisode p1 = new PodcastEpisode("AI Talk", 600, 2022, a1, "TechTalk", 1);
        PodcastEpisode p2 = new PodcastEpisode("Future", 500, 2023, a2, "Science", 2);

        // List
        ArrayList<Media> list = new ArrayList<>();
        list.add(s1);
        list.add(s2);
        list.add(s3);
        list.add(p1);
        list.add(p2);

  
        System.out.println("---- Play All ----");
        LibraryUtils.playAll(list);

        // Natural sort
        Collections.sort(list);
        System.out.println("\n---- Sorted (Natural) ----");
        for (Media m : list) {
            System.out.println(m);
        }

        // Comparator sort
        Collections.sort(list, new ByDurationAscending());
        System.out.println("\n---- Sorted by Duration ----");
        for (Media m : list) {
            System.out.println(m);
        }

        // Equals test
        System.out.println("\nEqual Songs: " + s1.equals(s3));

        // Total duration
        double total = LibraryUtils.totalDuration(list);
        System.out.println("\nTotal Duration: " + total);
    }
}