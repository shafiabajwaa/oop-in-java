public abstract class Media implements Playable, Comparable<Media> {
    private String title;
    private double durationSeconds;
    private int releaseYear;
    private Artist artist;

    public Media(String title, double durationSeconds, int releaseYear, Artist artist) {
        if (title == null || durationSeconds < 0 || releaseYear < 1877 || releaseYear > 2100) {
            throw new IllegalArgumentException("Invalid data");
        }

        this.title = title;
        this.durationSeconds = durationSeconds;
        this.releaseYear = releaseYear;
        this.artist = artist;  }

    public String getTitle() {
        return title;
    }

    public double getDurationSeconds() {
        return durationSeconds;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public Artist getArtist() {
        return artist;
    }

    @Override
    public int compareTo(Media other) {
        int result = this.title.compareToIgnoreCase(other.title);
        if (result == 0) {
            return this.releaseYear - other.releaseYear;
        }
        return result;
    }

    @Override
    public String toString() {
        return title + " (" + releaseYear + ")";
    }

    public abstract void play();
}