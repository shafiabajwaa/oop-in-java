import java.util.Comparator;

public class ByReleaseYearDescending implements Comparator<Media> {
    @Override
    public int compare(Media a, Media b) {
        if (a.getReleaseYear() > b.getReleaseYear()) return -1;
        if (a.getReleaseYear() < b.getReleaseYear()) return 1;
        return a.getTitle().compareToIgnoreCase(b.getTitle());
    }
}