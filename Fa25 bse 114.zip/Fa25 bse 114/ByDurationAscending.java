import java.util.Comparator;

public class ByDurationAscending implements Comparator<Media> {
    @Override
    public int compare(Media a, Media b) {
        if (a.getDurationSeconds() < b.getDurationSeconds()) return -1;
        if (a.getDurationSeconds() > b.getDurationSeconds()) return 1;
        return a.compareTo(b);
    }
}