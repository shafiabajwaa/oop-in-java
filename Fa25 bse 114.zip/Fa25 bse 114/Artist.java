public class Artist {
    private String name;
    private String country;
    private long followerCount;

    public Artist(String name, String country, long followerCount) {
        this.name = name;
        this.country = country;
        this.followerCount = followerCount;
    }

    public String getName() {
        return name;
    }

    public void addFollowers(long delta) {
        followerCount += delta;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Artist) {
            Artist other = (Artist) obj;
            return this.name.equalsIgnoreCase(other.name);
        }
        return false;
    }

    @Override
    public String toString() {
        return name + " (" + country + ")";
    }
}