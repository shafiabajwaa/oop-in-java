public class PodcastEpisode extends Media {
    private String showName;
    private int episodeNumber;

    public PodcastEpisode(String title, double duration, int year, Artist artist,
                          String showName, int episodeNumber) {
        super(title, duration, year, artist);

        if (episodeNumber < 1) {
            throw new IllegalArgumentException("Episode must be >= 1");
        }

        this.showName = showName;
        this.episodeNumber = episodeNumber;
    }

    @Override
    public void play() {
        System.out.println("Playing podcast \"" + showName + "\" Ep "
                + episodeNumber + ": " + getTitle());
    }
}