import java.util.ArrayList;

public class Playlist {
    private String name;
    private ArrayList<Media> items;

    public Playlist(String name) {
        this.name = name;
        items = new ArrayList<>();
   }

    public void add(Media m) {
        items.add(m);
  }

    public void remove(Media m) {
        items.remove(m);
 }

    public int size() {
        return items.size();
  }

    public Media get(int index) {
        return items.get(index);
 }

    public void playAll() {
        for (Media m : items) {
            m.play();
        } }}