import java.util.ArrayList;

public class LibraryUtils {

    public static double totalDuration(ArrayList<Media> list) {
        double sum = 0;
        for (Media m : list) {
            sum += m.getDurationSeconds();
    }
        return sum;
    }

    public static void playAll(ArrayList<Media> list) {
        for (Media m : list) {
            m.play();
      }
    }

    public static ArrayList<Song> songsInGenre(ArrayList<Media> list, String genre) {
        ArrayList<Song> result = new ArrayList<>();

        for (Media m : list) {
            if (m instanceof Song) {
                Song s = (Song) m;

                if (s.getGenre().equalsIgnoreCase(genre)) {
                    result.add(s);
                }
            }  }
        return result;
  }
}