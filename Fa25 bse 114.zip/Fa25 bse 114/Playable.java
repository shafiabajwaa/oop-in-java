public interface Playable {
    double getDurationSeconds();
    void play();
}